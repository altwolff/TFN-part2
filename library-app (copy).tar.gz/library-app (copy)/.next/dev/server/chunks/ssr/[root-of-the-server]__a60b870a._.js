module.exports = [
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[project]/src/app/layout.js [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/layout.js [app-rsc] (ecmascript)"));
}),
"[project]/src/app/page.js [app-rsc] (ecmascript)", ((__turbopack_context__, module, exports) => {

// // 'use client';
// // import { useState } from 'react';
// // import BookForm from '@/components/BookForm';
// // import BookList from '@/components/BookList';
// // export default function Home() {
// //     const [books, setBooks] = useState([]);
// //     const handleAddBook = (bookData) => {
// //         console.log('Book data received:', bookData);
// //         const newBook = {
// //             id: Date.now(),
// //             ...bookData
// //         };
// //         setBooks(prev => [...prev, newBook]);
// //         alert(`Book "${bookData.title}" added.`);
// //     };
// //     return (
// //         <div>
// //             {/* <h1>Test BookForm</h1> */}
// //             <BookForm onAddBook={handleAddBook} />
// //             <div>
// //                 {/* <h2>Added books: ({books.length}):</h2>
// //                 <pre>{JSON.stringify(books, null, 2)}</pre> */}
// //             </div>
// //         </div>
// //     );
// // }
// // // handleAddBook(bookData)
// // // handleDeleteBook(bookId)
// // // handleAddUser(userData)
// // // handleDeleteUser(userId)
// // // handleBorrowBook(bookId, userId)
// // // handleReturnBook(loanId)
// 'use client';
// import { useState } from 'react';
// import BookForm from '@/components/BookForm';
// import BookList from '@/components/BookList';
// export default function Home() {
//     const [books, setBooks] = useState([]);
//     const handleAddBook = (bookData) => {
//         console.log('Book data received:', bookData);
//         const newBook = {
//             id: Date.now(),
//             ...bookData,
//             available: parseInt(bookData.total),
//             total: parseInt(bookData.total)
//         };
//         setBooks(prev => [...prev, newBook]);
//     };
//     const handleDeleteBook = (bookId) => {
//         const book = books.find(b => b.id === bookId);
//         // Check if any copies are currently borrowed
//         if (book.available < book.total) {
//             alert('Cannot delete book - some copies are currently borrowed');
//             return;
//         }
//         setBooks(prev => prev.filter(book => book.id !== bookId));
//     };
//     return (
//         <div className="min-h-screen bg-gray-50 p-4">
//             <div className="max-w-7xl mx-auto">
//                 {/* Header */}
//                 <div className="text-center mb-8">
//                     <h1 className="text-4xl font-bold font-mono text-gray-800 mb-2">Library Management System</h1>
//                 </div>
//                 {/* Statistics Bar */}
//                 <div className="mt-8 bg-white rounded-lg shadow p-6 m-5">
//                     <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
//                         <div className="p-4 bg-blue-50 rounded-lg">
//                             <div className="text-2xl font-bold text-blue-600">{books.length}</div>
//                             <div className="text-sm text-gray-600">Total Books</div>
//                         </div>
//                         <div className="p-4 bg-green-50 rounded-lg">
//                             <div className="text-2xl font-bold text-green-600">
//                                 {books.filter(book => book.available > 0).length}
//                             </div>
//                             <div className="text-sm text-gray-600">Available Books</div>
//                         </div>
//                         <div className="p-4 bg-orange-50 rounded-lg">
//                             <div className="text-2xl font-bold text-orange-600">
//                                 {books.reduce((total, book) => total + book.total, 0)}
//                             </div>
//                             <div className="text-sm text-gray-600">Total Copies</div>
//                         </div>
//                         <div className="p-4 bg-purple-50 rounded-lg">
//                             <div className="text-2xl font-bold text-purple-600">
//                                 {books.reduce((total, book) => total + book.available, 0)}
//                             </div>
//                             <div className="text-sm text-gray-600">Available Copies</div>
//                         </div>
//                     </div>
//                 </div>
//                 {/* Main Content Grid */}
//                 <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
//                     {/* Left Column - Book Form */}
//                     <div>
//                         <BookForm onAddBook={handleAddBook} />
//                     </div>
//                     {/* Right Column - Book List */}
//                     <div>
//                         <BookList books={books} onDeleteBook={handleDeleteBook} />
//                     </div>
//                 </div>
//             </div>
//         </div>
//     );
// }
// 'use client';
// import { useState } from 'react';
// import BookForm from '@/components/BookForm';
// import BookList from '@/components/BookList';
// import UserForm from '@/components/UserForm';
// export default function Home() {
//     const [books, setBooks] = useState([]);
//     const [users, setUsers] = useState([]);
//     const [loans, setLoans] = useState([]);
//     const handleAddBook = (bookData) => {
//         console.log('Book data received:', bookData);
//         const newBook = {
//             id: Date.now(),
//             ...bookData,
//             available: parseInt(bookData.total),
//             total: parseInt(bookData.total)
//         };
//         setBooks(prev => [...prev, newBook]);
//     };
//     const handleDeleteBook = (bookId) => {
//         const book = books.find(b => b.id === bookId);
//         // Check if any copies are currently borrowed
//         if (book.available < book.total) {
//             alert('Cannot delete book - some copies are currently borrowed');
//             return;
//         }
//         setBooks(prev => prev.filter(book => book.id !== bookId));
//     };
//     const handleAddUser = (userData) => {
//         const newUser = {
//             id: Date.now(),
//             ...userData
//         };
//         setUsers(prev => [...prev, newUser]);
//     };
//     const handleDeleteUser = (userId) => {
//         // Add validation if user has active loans later
//         setUsers(prev => prev.filter(user => user.id !== userId));
//     };
//     const handleBorrowBook = (bookId, userId) => {
//         // To be implemented
//         console.log('Borrow book:', bookId, userId);
//     };
//     const handleReturnBook = (loanId) => {
//         // To be implemented
//         console.log('Return book:', loanId);
//     };
//     return (
//         <div className="min-h-screen bg-gray-50 p-4">
//             <div className="max-w-7xl mx-auto">
//                 {/* Header */}
//                 <div className="text-center mb-8">
//                     <h1 className="text-4xl font-bold font-mono text-gray-800 mb-2">Library Management System</h1>
//                 </div>
//                 {/* Statistics Bar */}
//                 <div className="mt-8 bg-white rounded-lg shadow p-6 m-5">
//                     <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
//                         <div className="p-4 bg-blue-50 rounded-lg">
//                             <div className="text-2xl font-bold text-blue-600">{books.length}</div>
//                             <div className="text-sm text-gray-600">Total Books</div>
//                         </div>
//                         <div className="p-4 bg-green-50 rounded-lg">
//                             <div className="text-2xl font-bold text-green-600">
//                                 {books.filter(book => book.available > 0).length}
//                             </div>
//                             <div className="text-sm text-gray-600">Available Books</div>
//                         </div>
//                         <div className="p-4 bg-orange-50 rounded-lg">
//                             <div className="text-2xl font-bold text-orange-600">
//                                 {users.length}
//                             </div>
//                             <div className="text-sm text-gray-600">Registered Users</div>
//                         </div>
//                         <div className="p-4 bg-purple-50 rounded-lg">
//                             <div className="text-2xl font-bold text-purple-600">
//                                 {books.reduce((total, book) => total + book.available, 0)}
//                             </div>
//                             <div className="text-sm text-gray-600">Available Copies</div>
//                         </div>
//                     </div>
//                 </div>
//                 {/* Main Content Grid */}
//                 <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
//                     {/* Left Column - Book Form + Book List */}
//                     <div className="space-y-8">
//                         <BookForm onAddBook={handleAddBook} />
//                         <BookList books={books} onDeleteBook={handleDeleteBook} />
//                     </div>
//                     {/* Right Column - User Form */}
//                     <div>
//                         <UserForm onAddUser={handleAddUser} existingUsers={users} />
//                     </div>
//                 </div>
//             </div>
//         </div>
//     );
// }
// 'use client';
// import { useState } from 'react';
// import BookForm from '@/components/BookForm';
// import BookList from '@/components/BookList';
// import UserForm from '@/components/UserForm';
// import UserList from '@/components/UserList';
// export default function Home() {
//     const [books, setBooks] = useState([]);
//     const [users, setUsers] = useState([]);
//     const [loans, setLoans] = useState([]);
//     const handleAddBook = (bookData) => {
//         console.log('Book data received:', bookData);
//         const newBook = {
//             id: Date.now(),
//             ...bookData,
//             available: parseInt(bookData.total),
//             total: parseInt(bookData.total)
//         };
//         setBooks(prev => [...prev, newBook]);
//     };
//     const handleDeleteBook = (bookId) => {
//         const book = books.find(b => b.id === bookId);
//         // Check if any copies are currently borrowed
//         if (book.available < book.total) {
//             alert('Cannot delete book - some copies are currently borrowed');
//             return;
//         }
//         setBooks(prev => prev.filter(book => book.id !== bookId));
//     };
//     const handleAddUser = (userData) => {
//         const newUser = {
//             id: Date.now(),
//             ...userData,
//             registrationDate: new Date().toISOString()
//         };
//         setUsers(prev => [...prev, newUser]);
//     };
//     const handleDeleteUser = (userId) => {
//         const userLoans = loans.filter(loan => loan.userId === userId);
//         if (userLoans.length > 0) {
//             alert('Cannot delete user with active book loans');
//             return;
//         }
//         setUsers(prev => prev.filter(user => user.id !== userId));
//     };
//     const handleBorrowBook = (bookId, userId) => {
//         // To be implemented
//         console.log('Borrow book:', bookId, userId);
//     };
//     const handleReturnBook = (loanId) => {
//         // To be implemented
//         console.log('Return book:', loanId);
//     };
//     return (
//         <div className="min-h-screen bg-gray-50 p-4">
//             <div className="max-w-7xl mx-auto">
//                 {/* Header */}
//                 <div className="text-center mb-8">
//                     <h1 className="text-4xl font-bold font-mono text-gray-800 mb-2">Library Management System</h1>
//                 </div>
//                 {/* Statistics Bar */}
//                 <div className="mt-8 bg-white rounded-lg shadow p-6 m-5">
//                     <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
//                         <div className="p-4 bg-blue-50 rounded-lg">
//                             <div className="text-2xl font-bold text-blue-600">{books.length}</div>
//                             <div className="text-sm text-gray-600">Total Books</div>
//                         </div>
//                         <div className="p-4 bg-green-50 rounded-lg">
//                             <div className="text-2xl font-bold text-green-600">
//                                 {books.filter(book => book.available > 0).length}
//                             </div>
//                             <div className="text-sm text-gray-600">Available Books</div>
//                         </div>
//                         <div className="p-4 bg-orange-50 rounded-lg">
//                             <div className="text-2xl font-bold text-orange-600">
//                                 {users.length}
//                             </div>
//                             <div className="text-sm text-gray-600">Registered Users</div>
//                         </div>
//                         <div className="p-4 bg-purple-50 rounded-lg">
//                             <div className="text-2xl font-bold text-purple-600">
//                                 {books.reduce((total, book) => total + book.available, 0)}
//                             </div>
//                             <div className="text-sm text-gray-600">Available Copies</div>
//                         </div>
//                     </div>
//                 </div>
//                 {/* Main Content Grid */}
//                 <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
//                     {/* Left Column - Book Form + Book List */}
//                     <div className="space-y-8">
//                         <BookForm onAddBook={handleAddBook} />
//                         <BookList books={books} onDeleteBook={handleDeleteBook} />
//                     </div>
//                     {/* Right Column - User Form + User List */}
//                     <div className="space-y-8">
//                         <UserForm onAddUser={handleAddUser} existingUsers={users} />
//                         <UserList users={users} loans={loans} onDeleteUser={handleDeleteUser} />
//                     </div>
//                 </div>
//             </div>
//         </div>
//     );
// }
// 'use client';
// import { useState } from 'react';
// import BookForm from '@/components/BookForm';
// import BookList from '@/components/BookList';
// import UserForm from '@/components/UserForm';
// import UserList from '@/components/UserList';
// import LoanManager from '@/components/LoanManager';
// export default function Home() {
//     const [books, setBooks] = useState([]);
//     const [users, setUsers] = useState([]);
//     const [loans, setLoans] = useState([]);
//     const handleAddBook = (bookData) => {
//         console.log('Book data received:', bookData);
//         const newBook = {
//             id: Date.now(),
//             ...bookData,
//             available: parseInt(bookData.total),
//             total: parseInt(bookData.total)
//         };
//         setBooks(prev => [...prev, newBook]);
//     };
//     const handleDeleteBook = (bookId) => {
//         const book = books.find(b => b.id === bookId);
//         // Check if any copies are currently borrowed
//         if (book.available < book.total) {
//             alert('Cannot delete book - some copies are currently borrowed');
//             return;
//         }
//         setBooks(prev => prev.filter(book => book.id !== bookId));
//     };
//     const handleAddUser = (userData) => {
//         const newUser = {
//             id: Date.now(),
//             ...userData,
//             registrationDate: new Date().toISOString()
//         };
//         setUsers(prev => [...prev, newUser]);
//     };
//     const handleDeleteUser = (userId) => {
//         const userLoans = loans.filter(loan => loan.userId === userId);
//         if (userLoans.length > 0) {
//             alert('Cannot delete user with active book loans');
//             return;
//         }
//         setUsers(prev => prev.filter(user => user.id !== userId));
//     };
//     const handleBorrowBook = (bookId, userId) => {
//         // Convert string IDs to numbers for comparison
//         const bookIdNum = parseInt(bookId);
//         const userIdNum = parseInt(userId);
//         const book = books.find(b => b.id === bookIdNum);
//         const user = users.find(u => u.id === userIdNum);
//         console.log('Borrowing - Book ID:', bookId, 'as number:', bookIdNum, 'Found book:', book);
//         console.log('Borrowing - User ID:', userId, 'as number:', userIdNum, 'Found user:', user);
//         console.log('All books:', books);
//         console.log('All users:', users);
//         if (!book || !user) {
//             alert(`Book or user not found. Book: ${!!book}, User: ${!!user}`);
//             return;
//         }
//         if (book.available <= 0) {
//             alert('Book not available');
//             return;
//         }
//         const userLoanCount = loans.filter(loan => loan.userId === userIdNum).length;
//         if (userLoanCount >= 5) {
//             alert('User has reached the maximum loan limit of 5 books');
//             return;
//         }
//         const newLoan = {
//             id: Date.now(),
//             bookId: bookIdNum,
//             userId: userIdNum,
//             loanDate: new Date().toISOString()
//         };
//         setLoans(prev => [...prev, newLoan]);
//         setBooks(prev => prev.map(b => 
//             b.id === bookIdNum ? { ...b, available: b.available - 1 } : b
//         ));
//         alert(`Book "${book.title}" successfully borrowed by ${user.name}`);
//     };
//     const handleReturnBook = (loanId) => {
//         const loan = loans.find(l => l.id === loanId);
//         if (!loan) return;
//         setLoans(prev => prev.filter(l => l.id !== loanId));
//         setBooks(prev => prev.map(b => 
//             b.id === loan.bookId ? { ...b, available: b.available + 1 } : b
//         ));
//     };
//     return (
//         <div className="min-h-screen bg-gray-50 p-4">
//             <div className="max-w-7xl mx-auto">
//                 {/* Header */}
//                 <div className="text-center mb-8">
//                     <h1 className="text-4xl font-bold font-mono text-gray-800 mb-2">Library Management System</h1>
//                 </div>
//                 {/* Statistics Bar */}
//                 <div className="mt-8 bg-white rounded-lg shadow p-6 m-5">
//                     <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
//                         <div className="p-4 bg-blue-50 rounded-lg">
//                             <div className="text-2xl font-bold text-blue-600">{books.length}</div>
//                             <div className="text-sm text-gray-600">Total Books</div>
//                         </div>
//                         <div className="p-4 bg-green-50 rounded-lg">
//                             <div className="text-2xl font-bold text-green-600">
//                                 {books.filter(book => book.available > 0).length}
//                             </div>
//                             <div className="text-sm text-gray-600">Available Books</div>
//                         </div>
//                         <div className="p-4 bg-orange-50 rounded-lg">
//                             <div className="text-2xl font-bold text-orange-600">
//                                 {users.length}
//                             </div>
//                             <div className="text-sm text-gray-600">Registered Users</div>
//                         </div>
//                         <div className="p-4 bg-purple-50 rounded-lg">
//                             <div className="text-2xl font-bold text-purple-600">
//                                 {loans.length}
//                             </div>
//                             <div className="text-sm text-gray-600">Active Loans</div>
//                         </div>
//                     </div>
//                 </div>
//                 {/* Main Content Grid */}
//                 <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
//                     {/* Left Column - Book Form + Book List */}
//                     <div className="space-y-8">
//                         <BookForm onAddBook={handleAddBook} />
//                         <BookList books={books} onDeleteBook={handleDeleteBook} />
//                     </div>
//                     {/* Right Column - User Form + User List */}
//                     <div className="space-y-8">
//                         <UserForm onAddUser={handleAddUser} existingUsers={users} />
//                         <UserList users={users} loans={loans} onDeleteUser={handleDeleteUser} />
//                     </div>
//                 </div>
//                 {/* Loan Manager - Full width */}
//                 <div>
//                     <LoanManager 
//                         books={books}
//                         users={users}
//                         loans={loans}
//                         onBorrowBook={handleBorrowBook}
//                         onReturnBook={handleReturnBook}
//                     />
//                 </div>
//             </div>
//         </div>
//     );
// }
}),
"[project]/src/app/page.js [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/page.js [app-rsc] (ecmascript)"));
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__a60b870a._.js.map