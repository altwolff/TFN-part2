import { useState } from 'react';

export default function LoanManager({ books, users, loans, onBorrowBook, onReturnBook }) {
    const [selectedBookId, setSelectedBookId] = useState('');
    const [selectedUserId, setSelectedUserId] = useState('');


    const availableBooks = books.filter(book => book.available > 0);

    const availableUsers = users.filter(user => {
        const userLoans = loans.filter(loan => loan.userId === user.id);
        return userLoans.length < 5;
    });

    const handleBorrow = () => {
        if (!selectedBookId || !selectedUserId) {
            alert('Please select both a user and a book');
            return;
        }

        onBorrowBook(selectedBookId, selectedUserId);
        setSelectedBookId('');
        setSelectedUserId('');
    };

    const formatDate = (dateString) => {
        return new Date(dateString).toLocaleDateString('pl-PL');
    };

    return (
        <div className="border font-mono p-4 m-4 rounded-md">
            <h2 className="text-2xl font-bold text-gray-800 mb-4">Loan Management</h2>

            <div className="border border-gray-400 rounded-md p-4 mb-6">
                <h3 className="text-lg font-bold text-gray-700 mb-3">New Loan</h3>
                <div className="space-y-4">
                
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                            Select User *
                        </label>
                        <select
                            value={selectedUserId}
                            onChange={(e) => setSelectedUserId(e.target.value)}
                            className="border border-gray-400 rounded-md p-2 w-full"
                        >
                            <option value="">Choose a user...</option>
                            {availableUsers.map(user => (
                                <option key={user.id} value={user.id}>
                                    {user.name} ({user.email}) - {loans.filter(loan => loan.userId === user.id).length}/5 loans
                                </option>
                            ))}
                        </select>
                        {availableUsers.length === 0 && users.length > 0 && (
                            <p className="text-red-500 font-bold italic mt-1">All users have reached the 5-book limit</p>
                        )}
                    </div>

                    
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                            Select Book *
                        </label>
                        <select
                            value={selectedBookId}
                            onChange={(e) => setSelectedBookId(e.target.value)}
                            className="border border-gray-400 rounded-md p-2 w-full"
                        >
                            <option value="">Choose a book...</option>
                            {availableBooks.map(book => (
                                <option key={book.id} value={book.id}>
                                    {book.title} by {book.author} ({book.available} available)
                                </option>
                            ))}
                        </select>
                        {availableBooks.length === 0 && books.length > 0 && (
                            <p className="text-red-500 font-bold italic mt-1">No books available for loan</p>
                        )}
                    </div>

                
                    <button
                        onClick={handleBorrow}
                        disabled={!selectedBookId || !selectedUserId}
                        className={`px-4 py-2 rounded-md font-medium transition-colors duration-200 ${selectedBookId && selectedUserId
                                ? 'bg-blue-600 text-white hover:bg-blue-700'
                                : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                            }`}
                    >
                        Borrow Book
                    </button>
                </div>
            </div>

    
            <div className="border border-gray-400 rounded-md p-4">
                <h3 className="text-lg font-bold text-gray-700 mb-3">Active Loans ({loans.length})</h3>

                {loans.length === 0 ? (
                    <div className="text-center py-4">
                        <p className="text-gray-500">No active loans</p>
                    </div>
                ) : (
                    <div className="space-y-3">
                        {loans.map(loan => {
                            const book = books.find(b => b.id === loan.bookId);
                            const user = users.find(u => u.id === loan.userId);

                            return (
                                <div key={loan.id} className="border border-gray-300 rounded-md p-3">
                                    <div className="flex justify-between items-start">
                                        <div className="flex-1">
                                            <h4 className="font-bold text-gray-800">{book?.title || 'Unknown Book'}</h4>
                                            <p className="text-sm text-gray-600">Borrowed by: {user?.name || 'Unknown User'}</p>
                                            <p className="text-sm text-gray-600">Loan Date: {formatDate(loan.loanDate)}</p>
                                            <p className="text-sm text-gray-600">Author: {book?.author || 'Unknown'}</p>
                                        </div>
                                        <button
                                            onClick={() => onReturnBook(loan.id)}
                                            className="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 transition-colors duration-200 ml-4"
                                        >
                                            Return
                                        </button>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                )}
            </div>

            <div className="mt-4 pt-4 border-t border-gray-200">
                <div className="grid grid-cols-2 gap-4 text-sm text-gray-600">
                    <div className="text-center">
                        <span className="font-semibold">{availableBooks.length}</span> books available
                    </div>
                    <div className="text-center">
                        <span className="font-semibold">{availableUsers.length}</span> users can borrow
                    </div>
                </div>
            </div>
        </div>
    );
}