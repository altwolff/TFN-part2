import { useState } from 'react';

export default function UserList({ users, loans, onDeleteUser }) {
    const [searchTerm, setSearchTerm] = useState('');

    const filteredUsers = users.filter(user =>
        user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        user.email.toLowerCase().includes(searchTerm.toLowerCase())
    );


    const getUserLoanCount = (userId) => {
        return loans.filter(loan => loan.userId === userId).length;
    };

    return (
        <div className="border font-mono p-4 m-4 rounded-md">
            <h2 className="text-2xl font-bold text-gray-800">User List</h2>
            
    
            <div className="my-4">
                <input
                    type="text"
                    placeholder="Search users..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="border border-gray-400 rounded-md p-2 w-full"
                />
            </div>

        
            <div className="mb-4">
                <p className="text-gray-600">
                    <span className="font-semibold">{filteredUsers.length}</span> of <span className="font-semibold">{users.length}</span> users
                    {searchTerm && (
                        <span> matching "<span className="font-semibold">{searchTerm}</span>"</span>
                    )}
                </p>
            </div>

        
            {filteredUsers.length === 0 ? (
                <div className="text-center py-8">
                    <p className="text-gray-500 text-lg font-medium">
                        {users.length === 0 ? 'No users registered yet' : 'No users found'}
                    </p>
                    <p className="text-gray-400 mt-2">
                        {users.length === 0 ? 'Add your first user using the form!' : 'Try adjusting your search terms'}
                    </p>
                </div>
            ) : (
                <div className="space-y-4">
                    {filteredUsers.map(user => {
                        const loanCount = getUserLoanCount(user.id);
                        const canDelete = loanCount === 0;

                        return (
                            <div key={user.id} className="border border-gray-400 rounded-md p-4">
                                <div className="flex justify-between items-start mb-2">
                                    <h3 className="text-lg font-bold text-gray-800 flex-1">{user.name}</h3>
                                    <span className={`px-2 py-1 rounded-full text-xs font-semibold ${
                                        loanCount > 0 ? 'bg-yellow-100 text-yellow-800' : 'bg-green-100 text-green-800'
                                    }`}>
                                        {loanCount > 0 ? `${loanCount} active loan${loanCount > 1 ? 's' : ''}` : 'No loans'}
                                    </span>
                                </div>
                                
                                <div className="space-y-2 text-sm text-gray-600 mb-4">
                                    <div className="flex items-center">
                                        <span className="font-medium w-16">Email:</span>
                                        <span>{user.email}</span>
                                    </div>
                                    <div className="flex items-center">
                                        <span className="font-medium w-16">Joined:</span>
                                        <span>{new Date(user.registrationDate || user.id).toLocaleDateString()}</span>
                                    </div>
                                </div>

                                <div className="flex justify-center">
                                    <button
                                        onClick={() => onDeleteUser(user.id)}
                                        disabled={!canDelete}
                                        className={`px-4 py-2 rounded-lg font-medium text-sm transition-colors ${
                                            canDelete 
                                                ? 'bg-red-600 text-white hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500' 
                                                : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                                        }`}
                                    >
                                        {canDelete ? 'Delete User' : 'Has Active Loans'}
                                    </button>
                                </div>
                            
                                {loanCount > 0 && (
                                    <div className="mt-3 pt-3 border-t border-gray-200">
                                        <p className="text-sm text-red-500 font-bold italic">
                                            Cannot delete user with active book loans
                                        </p>
                                    </div>
                                )}
                            </div>
                        );
                    })}
                </div>
            )}

        
            {users.length === 0 && (
                <div className="mt-4 text-center">
                    <p className="text-gray-500">No users registered yet!</p>
                </div>
            )}
        </div>
    );
}