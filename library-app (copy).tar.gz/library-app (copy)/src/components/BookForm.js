import { useState } from 'react';

export default function BookForm({ onAddBook }) {
    const [formData, setFormData] = useState({
        title: '',
        author: '',
        isbn: '',
        genre: '',
        total: ''
    });

    const [errors, setErrors] = useState({});

    const validateForm = () => {
        const newErrors = {};

        if (!formData.title.trim()) newErrors.title = 'Title is required.';
        if (!formData.author.trim()) newErrors.author = 'Author is required.';
        if (!formData.isbn.trim()) newErrors.isbn = 'ISBN is required.';
        if (!/^\d{13}$/.test(formData.isbn)) newErrors.isbn = 'ISBN needs to consist of 13 digits.';
        if (!formData.genre.trim()) newErrors.genre = 'Genre is required.';
        if (!formData.total || parseInt(formData.total) <= 0) newErrors.total = 'Total needs to be greater than 0.';

        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };


    const handleSubmit = (e) => {
        e.preventDefault();

        if (validateForm()) {
            onAddBook(formData);
            setFormData({
                title: '',
                author: '',
                isbn: '',
                genre: '',
                total: ''
            });

            setErrors({});
        }

    };


    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({
            ...prev,
            [name]: value
        }));


        if (errors[name]) {
            setErrors(prev => ({
                ...prev,
                [name]: ''
            }));
        }
    };


    return (
        <div className="border font-mono p-4 m-4 rounded-md">
            <h2 className="text-2xl font-bold text-gray-800">New Book</h2>
            <form onSubmit={handleSubmit} className="border border-gray-400 rounded-md p-2">
                <div>
                    <label>
                        Title *
                    </label>
                    <input
                        type="text"
                        name="title"
                        value={formData.title}
                        onChange={handleChange}
                        className={`border border-gray-400 rounded-md m-2 ${errors.title ? 'border-red-500' : ''}`}
                    />
                    {errors.title && <div className="text-red-500 font-bold italic">{errors.title}</div>}
                </div>

                <div>
                    <label>
                        Author *
                    </label>
                    <input
                        type="text"
                        name="author"
                        value={formData.author}
                        onChange={handleChange}
                        className={`border border-gray-400 rounded-md m-2 ${errors.author ? 'border-red-500' : ''}`}
                    />
                    {errors.author && <div className="text-red-500 font-bold italic">{errors.author}</div>}
                </div>

                <div>
                    <label>
                        ISBN *
                    </label>
                    <input
                        type="text"
                        name="isbn"
                        value={formData.isbn}
                        onChange={handleChange}
                        maxLength={13}
                        className={`border border-gray-400 rounded-md m-2 ${errors.isbn ? 'border-red-500' : ''}`}
                    />
                    {errors.isbn && <div className="text-red-500 font-bold italic">{errors.isbn}</div>}
                </div>

                <div>
                    <label>
                        Genre *
                    </label>
                    <input
                        type="text"
                        name="genre"
                        value={formData.genre}
                        onChange={handleChange}
                        className={`border border-gray-400 rounded-md m-2 ${errors.genre ? 'border-red-500' : ''}`}
                    />
                    {errors.genre && <div className="text-red-500 font-bold italic">{errors.genre}</div>}
                </div>

                <div>
                    <label>
                        No. of copies *
                    </label>
                    <input
                        type="number"
                        name="total"
                        value={formData.total}
                        onChange={handleChange}
                        min="1"
                        className={`border border-gray-400 rounded-md m-2 ${errors.total ? 'border-red-500' : ''}`}
                    />
                    {errors.total && <div className="text-red-500 font-bold italic">{errors.total}</div>}
                </div>

                <button type="submit" className="bg-blue-400 text-white py-2 px-4 my-2 rounded-md hover:bg-blue-500 transition-colors duration-200">Add book</button>
            </form>
        </div>
    );
}