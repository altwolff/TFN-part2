import { useState } from 'react';

export default function UserForm({ onAddUser, existingUsers = [] }) {
    const [formData, setFormData] = useState({
        name: '',
        email: ''
    });

    const [errors, setErrors] = useState({});

    const validateForm = () => {
        const newErrors = {};

        if (!formData.name.trim()) {
            newErrors.name = 'Name is required.';
        }

        if (!formData.email.trim()) {
            newErrors.email = 'Email is required.';
        } else if (!formData.email.includes('@')) {
            newErrors.email = 'Email must contain @ symbol.';
        } else {
            
            const emailExists = existingUsers.some(user => 
                user.email.toLowerCase() === formData.email.toLowerCase()
            );
            if (emailExists) {
                newErrors.email = 'User with this email already exists.';
            }
        }

        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = (e) => {
        e.preventDefault();

        if (validateForm()) {
            onAddUser(formData);
            setFormData({
                name: '',
                email: ''
            });
            setErrors({});
        }
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({
            ...prev,
            [name]: value
        }));
        
        
        if (errors[name]) {
            setErrors(prev => ({
                ...prev,
                [name]: ''
            }));
        }
    };

    return (
        <div className="border font-mono p-4 m-4 rounded-md">
            <h2 className="text-2xl font-bold text-gray-800">New User</h2>
            <form onSubmit={handleSubmit} className="border border-gray-400 rounded-md p-2">
        
                <div>
                    <label>
                        Full Name *
                    </label>
                    <input
                        type="text"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        className={`border border-gray-400 rounded-md m-2 ${errors.name ? 'border-red-500' : ''}`}
                    />
                    {errors.name && <div className="text-red-500 font-bold italic">{errors.name}</div>}
                </div>

        
                <div>
                    <label>
                        Email Address *
                    </label>
                    <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        className={`border border-gray-400 rounded-md m-2 ${errors.email ? 'border-red-500' : ''}`}
                    />
                    {errors.email && <div className="text-red-500 font-bold italic">{errors.email}</div>}
                </div>

            
                <button 
                    type="submit" 
                    className="bg-green-400 text-white py-2 px-4 my-2 rounded-md hover:bg-green-500 transition-colors duration-200"
                >
                    Add User
                </button>
            </form>

    
            <div className="mt-4 pt-4 border-t border-gray-200">
                <p className="text-sm text-gray-600 text-center">
                    Total registered users: <span className="font-semibold">{existingUsers.length}</span>
                </p>
            </div>
        </div>
    );
}