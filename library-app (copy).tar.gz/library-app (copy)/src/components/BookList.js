import { useState } from 'react';

export default function BookList({ books, onDeleteBook }) {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredBooks = books.filter(book =>
    book.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    book.author.toLowerCase().includes(searchTerm.toLowerCase())
  );


  return (
    <div className="border font-mono p-4 m-4 rounded-md">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
        <h2 className="text-2xl font-bold text-gray-800">Book Collection</h2>
        <div className="w-full sm:w-64">
          <input
            type="text"
            placeholder="Search books..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>
      </div>
      <div className="mb-6">
        <p className="text-gray-600">
          <span className="font-semibold">{filteredBooks.length}</span> of <span className="font-semibold">{books.length}</span> books
          {searchTerm && (
            <span> matching "<span className="font-semibold">{searchTerm}</span>"</span>
          )}
        </p>
      </div>
      {filteredBooks.length === 0 ? (
        <div className="text-center py-12">
          <div className="text-gray-400 text-6xl mb-4">📚</div>
          <p className="text-gray-500 text-lg font-medium">
            {books.length === 0 ? 'No books in your library' : 'No books found'}
          </p>
          <p className="text-gray-400 mt-2">
            {books.length === 0 ? 'Add your first book to get started' : 'Try adjusting your search terms'}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredBooks.map(book => (
            <div key={book.id} className="bg-white border border-gray-200 rounded-xl shadow-md hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
              <div className="p-6 border-b border-gray-100">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="text-lg font-bold text-gray-800 flex-1 italic">{book.title}</h3>
                </div>
                <p className="text-gray-600 text-sm">by {book.author}</p>
                <div className="flex justify-center mt-2">
                  <span
                    className={`px-2 py-1 rounded-full text-xs font-semibold ${book.available > 0
                      ? 'bg-green-100 text-green-800'
                      : 'bg-red-100 text-red-800'
                      }`}
                  >
                    {book.available > 0 ? 'Available' : 'Borrowed'}
                  </span>
                </div>
              </div>
              <div className="p-6">
                <div className="space-y-3">
                  <div className="flex items-center text-sm text-gray-600">
                    <span className="font-medium w-16">Genre:</span>
                    <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded text-xs font-medium truncate">
                      {book.genre}
                    </span>
                  </div>
                  <div className="flex items-center text-sm text-gray-600">
                    <span className="font-medium w-16">ISBN:</span>
                    <span className="font-mono bg-gray-100 px-2 py-1 rounded text-xs truncate block w-full">
                      {book.isbn}
                    </span>
                  </div>
                  <div className="pt-2">
                    <div className="flex justify-between text-sm text-gray-600 mb-1">
                      <span className="mr-2">Availability</span>
                      <span className="font-semibold">{book.available}/{book.total}</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div
                        className={`h-2 rounded-full ${book.available === book.total ? 'bg-green-500' :
                          book.available === 0 ? 'bg-red-500' : 'bg-yellow-500'
                          }`}
                        style={{ width: `${(book.available / book.total) * 100}%` }}
                      ></div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="px-6 py-4 bg-gray-50 rounded-b-xl border-t border-gray-100">
                <div className="flex justify-center items-center">
                  <div className="flex justify-center">
                    <button
                      onClick={() => onDeleteBook(book.id)}
                      disabled={book.available < book.total}
                      className={`px-4 py-2 rounded-lg font-medium text-sm transition-colors ${book.available < book.total
                        ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                        : 'bg-red-600 text-white hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500'
                        }`}
                    >
                      {book.available < book.total ? 'Borrowed' : 'Delete'}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}