export default function Statistics({ books, users, loans }) {
    const totalBooks = books.length;
    const availableBooks = books.filter(book => book.available > 0).length;
    const borrowedBooks = books.filter(book => book.available < book.total).length;
    const totalUsers = users.length;
    const activeLoans = loans.length;

    const stats = [
        {
            label: 'Total Books',
            value: totalBooks,
            description: 'Unique book titles in library',
            color: 'blue'
        },
        {
            label: 'Available Books',
            value: availableBooks,
            description: 'Books ready to borrow',
            color: 'green'
        },
        {
            label: 'Borrowed Books',
            value: borrowedBooks,
            description: 'Books with borrowed copies',
            color: 'orange'
        },
        {
            label: 'Registered Users',
            value: totalUsers,
            description: 'Total library members',
            color: 'purple'
        },
        {
            label: 'Active Loans',
            value: activeLoans,
            description: 'Current book loans',
            color: 'red'
        }
    ];

    const colorClasses = {
        blue: 'bg-blue-50 border-blue-200 text-blue-600',
        green: 'bg-green-50 border-green-200 text-green-600',
        orange: 'bg-orange-50 border-orange-200 text-orange-600',
        purple: 'bg-purple-50 border-purple-200 text-purple-600',
        red: 'bg-red-50 border-red-200 text-red-600'
    };

    return (
        <div className="border font-mono p-4 m-4 rounded-md">
            <h2 className="text-2xl font-bold text-gray-800 mb-4 text-center">Library Statistics</h2>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
                {stats.map((stat, index) => (
                    <div 
                        key={index}
                        className={`border rounded-lg p-4 text-center ${colorClasses[stat.color]}`}
                    >
                        <div className="text-2xl font-bold">{stat.value}</div>
                        <div className="text-sm font-semibold mb-1">{stat.label}</div>
                        <div className="text-xs text-gray-500">{stat.description}</div>
                    </div>
                ))}
            </div>
        </div>
    );
}