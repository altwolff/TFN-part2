'use client';
import { useState } from 'react';
import BookForm from '@/components/BookForm';
import BookList from '@/components/BookList';
import UserForm from '@/components/UserForm';
import UserList from '@/components/UserList';
import LoanManager from '@/components/LoanManager';
import Statistics from '@/components/Statistics';

export default function Home() {
    const [books, setBooks] = useState([]);
    const [users, setUsers] = useState([]);
    const [loans, setLoans] = useState([]);

    const handleAddBook = (bookData) => {
        console.log('Book data received:', bookData);

        const newBook = {
            id: Date.now(),
            ...bookData,
            available: parseInt(bookData.total),
            total: parseInt(bookData.total)
        };

        setBooks(prev => [...prev, newBook]);
    };

    const handleDeleteBook = (bookId) => {
        const book = books.find(b => b.id === bookId);

       
        if (book.available < book.total) {
            alert('Cannot delete book - some copies are currently borrowed');
            return;
        }

        setBooks(prev => prev.filter(book => book.id !== bookId));
    };

    const handleAddUser = (userData) => {
        const newUser = {
            id: Date.now(),
            ...userData,
            registrationDate: new Date().toISOString()
        };
        setUsers(prev => [...prev, newUser]);
    };

    const handleDeleteUser = (userId) => {
        const userLoans = loans.filter(loan => loan.userId === userId);
        
        if (userLoans.length > 0) {
            alert('Cannot delete user with active book loans');
            return;
        }
        
        setUsers(prev => prev.filter(user => user.id !== userId));
    };

    const handleBorrowBook = (bookId, userId) => {
        
        const bookIdNum = parseInt(bookId);
        const userIdNum = parseInt(userId);
        
        const book = books.find(b => b.id === bookIdNum);
        const user = users.find(u => u.id === userIdNum);
        
        if (!book || !user) {
            alert('Book or user not found');
            return;
        }
        
        if (book.available <= 0) {
            alert('Book not available');
            return;
        }

        const userLoanCount = loans.filter(loan => loan.userId === userIdNum).length;
        if (userLoanCount >= 5) {
            alert('User has reached the maximum loan limit of 5 books');
            return;
        }

        const newLoan = {
            id: Date.now(),
            bookId: bookIdNum,
            userId: userIdNum,
            loanDate: new Date().toISOString()
        };
        
        setLoans(prev => [...prev, newLoan]);
        setBooks(prev => prev.map(b => 
            b.id === bookIdNum ? { ...b, available: b.available - 1 } : b
        ));
        
        alert(`Book "${book.title}" successfully borrowed by ${user.name}`);
    };

    const handleReturnBook = (loanId) => {
        const loan = loans.find(l => l.id === loanId);
        if (!loan) return;
        
        setLoans(prev => prev.filter(l => l.id !== loanId));
        setBooks(prev => prev.map(b => 
            b.id === loan.bookId ? { ...b, available: b.available + 1 } : b
        ));
    };

    return (
        <div className="min-h-screen bg-gray-50 p-4">
            <div className="max-w-7xl mx-auto">
               
                <div className="text-center mb-8">
                    <h1 className="text-4xl font-bold font-mono text-gray-800 mb-2">Library Management System</h1>
                </div>

               
                <Statistics books={books} users={users} loans={loans} />

               
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 my-8">
                   
                    <div className="space-y-8">
                        <BookForm onAddBook={handleAddBook} />
                        <BookList books={books} onDeleteBook={handleDeleteBook} />
                    </div>

                  
                    <div className="space-y-8">
                        <UserForm onAddUser={handleAddUser} existingUsers={users} />
                        <UserList users={users} loans={loans} onDeleteUser={handleDeleteUser} />
                    </div>
                </div>

        
                <div>
                    <LoanManager 
                        books={books}
                        users={users}
                        loans={loans}
                        onBorrowBook={handleBorrowBook}
                        onReturnBook={handleReturnBook}
                    />
                </div>
            </div>
        </div>
    );
}